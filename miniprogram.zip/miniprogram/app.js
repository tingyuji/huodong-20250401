//app.js
// 假设使用ES6模块化规范引入
import EventEmitter from './eventEmitter.js';
App({
  onLaunch: function () {

     // 创建EventEmitter实例
    //  const myEmitter = new EventEmitter();
    //  this.myEmitter = myEmitter;

     // 示例：添加一个事件监听器
    //  myEmitter.on('someEvent', function () {
    //    console.log('Some event occurred!');
    //  });
 
     // 示例：触发事件
    //  myEmitter.emit('someEvent');

    
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        env: 'cloud1-5gs4xso4fbd5e5ab',
        traceUser: true,
      })
    }

    this.globalData = {
      myEmitter: new EventEmitter(),
      fileUrl: '',
      fileType: '',
      shareImg02: "https://pic1.zhimg.com/v2-167ceaa064ce74ba18a7ff19947bdd12.png",
      name: '',
      tel: '',
      dept: '',
      amount: 0,
      map: {
        '01': 0,
        '02': 0,
        '03': 0
      },
      voteItems: [],
      sortcode: 1,
      num: 100,
        checkMode: false,
        mode: '001',
        shareImage: 'https://pic1.zhimg.com/v2-167ceaa064ce74ba18a7ff19947bdd12.png',
        lottery: 0,
        userInfo: {
          nickName: '未授权，请点击头像登录授权',
          avatarUrl: 'https://pica.zhimg.com/v2-43aeeecef2489620b09ea9c8f4ac6dad.png'
        },
        mylevel: {},
        enemy: {
          nickName: '待邀请',
          avatarUrl: 'https://pica.zhimg.com/v2-43aeeecef2489620b09ea9c8f4ac6dad.png'
        },
        match: {
          nickName: '待匹配',
          avatarUrl: 'https://pica.zhimg.com/v2-43aeeecef2489620b09ea9c8f4ac6dad.png'
        },
        group_name: "",
        device: {},
        user_id: 0,
        goEasy: null,
        title: "东部力量·心路护航",
        sharetitle: "东部力量·心路护航",
        jiangArr: [],
        shijian: []
    }
  }
})
