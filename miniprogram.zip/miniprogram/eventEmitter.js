// By default EventEmitters will print a warning if more than
// 10 listeners are added to it. This is a useful default which
// helps finding memory leaks.
//
// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
const defaultMaxListeners = 10;

class EventEmitter {
    constructor() {
        this._events = new Map();
        this._maxListeners = defaultMaxListeners;
    }

    setMaxListeners(n) {
        this._maxListeners = n;
    }

    emit(type, ...args) {
        // If there is no 'error' event listener then throw.
        if (type === 'error') {
            const errorListeners = this._events.get('error');
            if (!errorListeners || errorListeners.length === 0) {
                const error = args[0] instanceof Error ? args[0] : new Error('Uncaught, unspecified "error" event.');
                throw error;
            }
        }

        const handlers = this._events.get(type);
        if (!handlers) return false;

        handlers.forEach(handler => handler(...args));
        return true;
    }

    // EventEmitter is defined in src/node_events.cc
    // EventEmitter.prototype.emit() is also defined there.
    addListener(type, listener) {
        if (typeof listener !== 'function') {
            throw new Error('addListener only takes instances of Function');
        }

        let listeners = this._events.get(type);

        if (!listeners) {
            listeners = [];
            this._events.set(type, listeners);
        }

        if (!listeners.warned) {
            if (this._maxListeners > 0 && listeners.length >= this._maxListeners) {
                listeners.warned = true;
                console.error(`(node) warning: possible EventEmitter memory leak detected. ${listeners.length} listeners added. Use emitter.setMaxListeners() to increase limit.`);
                console.trace();
            }
        }

        listeners.push(listener);
        return this;
    }

    once(type, listener) {
        const onceHandler = (...args) => {
            this.removeListener(type, onceHandler);
            listener(...args);
        };
        this.on(type, onceHandler);
        return this;
    }

    removeListener(type, listener) {
        if (typeof listener !== 'function') {
            throw new Error('removeListener only takes instances of Function');
        }

        const listeners = this._events.get(type);
        if (listeners) {
            const index = listeners.indexOf(listener);
            if (index !== -1) {
                listeners.splice(index, 1);
                if (listeners.length === 0) {
                    this._events.delete(type);
                }
            }
        }
        return this;
    }

    removeAllListeners(type) {
        if (type) {
            this._events.delete(type);
        } else {
            this._events.clear();
        }
        return this;
    }

    listeners(type) {
        const listeners = this._events.get(type);
        return listeners ? [...listeners] : [];
    }
}

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

export default EventEmitter;