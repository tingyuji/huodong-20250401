//在使用的View中引入WxParse模块
var WxParse = require('../../wxParse/wxParse.js');
var util = require('../../utils/util.js');
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    num: 60,
    total: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.addinfo(options);

    this.setData({
      id: options.id
    },()=>{
      this.onQuery();
      this.updateNum();
      var article = '<div>我是HTML代码</div>';
    })

    /**
    * WxParse.wxParse(bindName , type, data, target,imagePadding)
    * 1.bindName绑定的数据名(必填)
    * 2.type可以为html或者md(必填)
    * 3.data为传入的具体数据(必填)
    * 4.target为Page对象,一般为this(必填)
    * 5.imagePadding为当图片自适应是左右的单一padding(默认为0,可选)
    */
    var that = this;
    // WxParse.wxParse('article', 'html', article, that, 5);
  },
  adLoad() {
    console.log('原生模板广告加载成功')
  },
  adError(err) {
    console.error('原生模板广告加载失败', err)
  },
  adClose() {
    console.log('原生模板广告关闭')
  },
  updateNum: function(name){

    const db = wx.cloud.database();
    const _ = db.command;
    db.collection('article').doc(this.data.id).update({
      // data 字段表示需新增的 JSON 数据
      data: {
        num: _.inc(1)
      }
    })
    .then(res => {
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);

    })
    .catch((err)=>{
      console.log(err)
    })
  },
  addinfo: function(options){

    return;
    
    let time = util.getTime(new Date());

    const db = wx.cloud.database();
    db.collection('logs').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        path:"pages/article/article",
        ...options,
        time,
        updateTime: Date.now()
      }
    })
    .then(res => {

      console.log(res)

    })
    .catch((err)=>{
   
      console.log(err)
    })
  },
  add: async function(num){
    let {name,time,today} = app.globalData;
    const db = wx.cloud.database();
    const $ = db.command.aggregate
    db.collection('actions').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        action: '知识之旅',
        name,
        num,
        today,
        time,
        updateTime: Date.now()
      }
    })
    .then(res => {
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
      this.update(num);
    })
    .catch((err)=>{
      console.log(err)
    })
  },
  update: function(num){
    const db = wx.cloud.database();
    const _ = db.command;
    db.collection('profiles').doc(app.globalData.openid).update({
      // data 字段表示需新增的 JSON 数据
      data: {
        num: _.inc(num),
        total: _.inc(num),
        items: _.push(num)
      }
    })
    .then(res => {
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
      
      wx.showToast({
        title: '获得1积分',
        icon: 'success',
        duration: 2000
      })
      
    })
    .catch((err)=>{
      console.log(err)
    })
  },

  addRecord: function(){
    if(this.data.total > 20){
      return;
    }
    // 在小程序代码中：
    let that = this;
    wx.cloud.callFunction({
      name: 'addRecord',
      data: {
        id: this.data.id
      }
    })
    .then(res=>{
      console.log('callFunction addRecord result: ', res);
      if(res.result){
        // 2022-10-15
        // 活动结束积分不增加了
        this.add(1);
      }
      this.onQueryDone();
      // {
      //   "result": {
      //     "_id": "49ae921b0a26147056fd67737e19d121",
      //     "errMsg": "collection.add:ok"
      //   },
      //   "requestID": "8c151767-b0aa-4aaf-84f6-08acb74d174f"
      // }

    })
    .catch(err=>{
      console.error('[云函数] [addRecord] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },

  onQueryDone: function(){

    // 在小程序代码中：
    let that = this;
    wx.cloud.callFunction({
      name: 'fetchRecords',
      data: {
        
      }
    })
    .then(res=>{
      console.log('callFunction addRecord result: ', res);
      let items = res.result.data;
      let arr = [];
      items.forEach(element => {
        arr.push(element.art);
      });
      app.globalData.doneItems = arr;
      console.log('app.globalData.doneItems ',app.globalData.doneItems );

    })
    .catch(err=>{
      console.error('[云函数] [addRecord] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },

  onQuery: function(){
    // 在小程序代码中：
    let that = this;
    wx.cloud.callFunction({
      name: 'fetchOneArt',
      data: {
        id: this.data.id
      }
    })
    .then(res=>{
      console.log('callFunction fetchOneArt result: ', res);
      let data = res.result.data;

      this.setData({
        obj: data
      })
      let html = data.html;
      WxParse.wxParse('article', 'html', html, that, 5);

    })
    .catch(err=>{
      console.error('[云函数] [fetchOneArt] 调用失败', err)
      
    })
  },
  _onQuery: function(id){
    let that = this;
    const db = wx.cloud.database()
    db.collection('article').doc(id).get().then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
      let item = res.data;
      this.setData({
        obj: res.data
      })
      let html = item.html; 
      WxParse.wxParse('article', 'html', html, that, 5);
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // this.timeDown();
  },
  timeDown: function(){
    let num = 60;
    app.globalData.timeer = setInterval(() => {
      num--;
      this.setData({
        num
      },()=>{
        if(num <= 0 ){
          clearInterval(app.globalData.timeer);
          this.addRecord();
        }
      })
    }, 1000);
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.setNavigationBarTitle({
      title: "活动说明"
    });

    
    this.onGetOpenid();
    
  },
  toBack: function(){
    wx.navigateBack({
      delta: 1
    })
  },
  toQrcode: function(){
    wx.navigateTo({
      url: '../pic/pic'
    });
  },
  onGetOpenid: function() {
    // 调用云函数
    let that = this;
    wx.cloud.callFunction({
      name: 'login',
      data: {

      }
    })
    .then(res => {
      console.log('[云函数] [login]: ', res)
      app.globalData.openid = res.result.openid;
      let openid = res.result.openid;
      console.log(openid);

      that.setData({
        openid:openid,
      },()=>{
        this.check();
      });
      
    }).catch(err => {
      console.error('[云函数] [login] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  check: async function(){
    const db = wx.cloud.database()
    const _ = db.command

    console.log({
      _openid: app.globalData.openid,
      today: app.globalData.today
    });

    const res = await db.collection('records').where({
    _openid: app.globalData.openid,
    today: app.globalData.today
    }).count();

    console.log(res);

    this.setData({
      total: res.total
    })

    if(res.total >= 20){
      wx.showModal({
        showCancel: false,
        title: '温馨提示',
        confirmText: '我知道了',
        content: '今天阅读任务已达标，后面阅读没有积分',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })  
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: this.data.obj.title || app.globalData.title,
      path: "pages/article/article?id="+this.data.id+"&fromOpenid="+this.data.openid,
      imageUrl: app.globalData.shareImage
    };
  }
})