// pages/pic/pic.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    noMoreLottery: true,
    map: {
      0: 'https://picx.zhimg.com/v2-9590c4fe32c9f9cb53408a044af45c0f.png',
      1: 'https://picx.zhimg.com/v2-80e0d91181f45984277e6f47b9cd7651.png',
      2: 'https://picx.zhimg.com/v2-0285dcb717c928bad352499b244c7afd.png'
    },
    currentPage: 1,
    loaded: true,
    itemid: '00',
    name: '',
    images: [],
    num: '',
    total: '',
    view: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  bindNameInput: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  onQuery: function(){
    let that = this;
    wx.cloud.callFunction({
    name: 'fetchRank',
    data: {
        
    }
    })
    .then(res => {
      console.log('[云函数] [fetchRank]: ', res)
      let items = res.result.list;
      
      this.setData({
        items,
      },()=>{
        wx.hideLoading()
      });
    
    }).catch(err => {
      console.error('[云函数] [fetchRank] 调用失败', err)

    })
  },
  onQueryByName: function(){
    let that = this;
    let name = this.data.name;
    wx.cloud.callFunction({
    name: 'fetchPhotoByName',
    data: {
        name
    }
    })
    .then(res => {
      console.log('[云函数] [fetchPhotoByName]: ', res)
      let items = res.result.list;
      items.forEach(element => {
        element.vote = app.globalData.voteItems.indexOf(element._id) != -1;
      });
      let images = items.map(item=>{
        return item.fileUrl;
      })
      
      this.setData({
        items,
        images
      },()=>{
        wx.hideLoading()
      });
    
    }).catch(err => {
      console.error('[云函数] [fetchPhotoByName] 调用失败', err)

    })
  },
  onQueryByItemid: function(){
    let that = this;
    let itemid = this.data.itemid;
    wx.cloud.callFunction({
    name: 'fetchRankByItemid',
    data: {
      itemid
    }
    })
    .then(res => {
      console.log('[云函数] [fetchRankByItemid]: ', res)
      let items = res.result.list;
      
      this.setData({
        items,
      },()=>{
        wx.hideLoading()
      });
    
    }).catch(err => {
      console.error('[云函数] [fetchRankByItemid] 调用失败', err)

    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.onQuery();
    this.onQueryVote();
    this.update();
    this.onQueryVoteItems();
  },

  onQueryVoteItems: function(itemid){
    // 调用云函数
    let that = this;
    let map = app.globalData.map;
    wx.cloud.callFunction({
    name: 'fetchVote',
    data: {
        
    }
    })
    .then(res => {
      console.log('[云函数] [fetchVote]: ', res)
      let list = res.result.data;
      let items = [];
      list.forEach(element => {
        items.push(element.voteid);
        map[element.itemid]++;
      });
      app.globalData.voteItems = items;
      app.globalData.map = map;
    
    }).catch(err => {
      console.error('[云函数] [fetchVote] 调用失败', err)

    })
  },
  onQueryVote: function(){
    let that = this;
    const db = wx.cloud.database()

    let _id = '6a580dc96803059e016c8f511ce41621';
    db.collection('voteinfo')
    .doc(_id)
    .get()
    .then(res => {
      console.log('[数据库] [查询记录] 成功: ', res)
      let {num, total, view} = res.data

      this.setData({
        'num': num,
        'total': total,
        'view': view
      },()=>{
      })

    })
    .catch(err=>{
      console.error('[数据库] [查询记录] 失败：', err)
      
    })
  },
  update: function(){
        
    const db = wx.cloud.database();
    const _ = db.command;

    let _id = '6a580dc96803059e016c8f511ce41621';
    db.collection('voteinfo').doc(_id).update({
      // data 字段表示需新增的 JSON 数据
      data: {
        view: _.inc(1)
      }
    })
    .then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
    })
    .catch((err)=>{
      console.log(err)
    })
  },
  update2: function(){
        
    const db = wx.cloud.database();
    const _ = db.command;

    let _id = '6a580dc96803059e016c8f511ce41621';
    db.collection('voteinfo').doc(_id).update({
      // data 字段表示需新增的 JSON 数据
      data: {
        total: _.inc(1)
      }
    })
    .then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
    })
    .catch((err)=>{
      console.log(err)
    })
  },
  _onQuery: function(){
    let _openid = app.globalData.openid;
    console.log(JSON.stringify(app.globalData.voteItems))
    const db = wx.cloud.database()
    db.collection('photo')
    .orderBy('num', 'desc')
    .get()
    .then(res=>{
      console.log('[数据库] [查询记录] 成功: ', res);
      let items = res.data;
      
      this.setData({
        items,
      },()=>{
        wx.hideLoading()
      });

    })
    .catch(err=>{
      console.error('[数据库] [查询记录] 失败：', err)
      wx.showToast({
        icon: 'none',
        title: '查询记录失败'
      })
      
    })
  },

  onQueryMore: function() {
    wx.showNavigationBarLoading();
    console.log('onQueryMoreLottery')
    console.log('this.data.currentPage',this.data.currentPage)
    let currentPage = this.data.currentPage+1;
    console.log('currentPage',currentPage)
    

    let pageIndex = currentPage - 1;
    let pageSize = 20;
    let skipIndex = pageIndex * pageSize;

    console.log(skipIndex,pageSize);

    const db = wx.cloud.database()
    db.collection('photo')
    .aggregate()
    .sort({
      num: -1
    })
    .skip(skipIndex)
    .limit(pageSize)
    .end().then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
      let items = res.list || [];
      items.forEach(element => {
        element.vote = app.globalData.voteItems.indexOf(element._id) != -1;
      });

      this.setData({
        currentPage,
        items: this.data.items.concat(items)
      });
      wx.hideNavigationBarLoading();
    })
  },

  preview(){
    let image = this.data.images[0];
    wx.previewImage({
      current: image, // 当前显示图片的http链接
      urls: this.data.images // 需要预览的图片http链接列表
    })
  },
  updateItemId: function(e){
    console.log(e.currentTarget.dataset.itemid);
    let itemid = e.currentTarget.dataset.itemid;
    this.setData({
      itemid: itemid
    },()=>{
      if(itemid == '00'){
        this.onQuery();
      }
      if(itemid == '01' || itemid == '02' || itemid == '03'){
        this.onQueryByItemid();
      }
      
    })
  },
  vote: function(e){
    console.log(e.currentTarget.dataset.index);
    console.log(e.currentTarget.dataset.id);
    
    let index = e.currentTarget.dataset.index;
    let id = e.currentTarget.dataset.id;
    let itemid = e.currentTarget.dataset.itemid;

    let map = app.globalData.map;
    if(map[itemid] > 3){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '当前类型作品投票已达上限',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })  
      return
    }
    
    // 调用云函数
    let that = this;
    wx.cloud.callFunction({
    name: 'vote',
    data: {
        id: id
    }
    })
    .then(res => {
      console.log('[云函数] [vote]: ', res)
      let key = 'items[' + index + '].vote'
      this.setData({
        [key]: true 
      })
      this.update2();
      this.add(id,itemid);
      wx.showToast({
        title: "投票成功",
        icon: "none",
        duration: 2e3
      });
      map[itemid]++;
      console.log(JSON.stringify(map));

    
    }).catch(err => {
      console.error('[云函数] [vote] 调用失败', err)

    })
  },
  add: function(id,itemid){
    // 调用云函数
    let that = this;
    wx.cloud.callFunction({
    name: 'add',
    data: {
      id,
      itemid
    }
    })
    .then(res => {
      console.log('[云函数] [add]: ', res)
    
    }).catch(err => {
      console.error('[云函数] [add] 调用失败', err)

    })
  },
  toRank: function(){
    let url = '/pages/rank/rank';
    wx.navigateTo({
      url: url
    })

  },
  toDetail: function(e){
    console.log(e.currentTarget.dataset.id);
    let id = e.currentTarget.dataset.id;
    let url = '/pages/detail/detail?id='+id;
    wx.navigateTo({
      url: url
    })

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
   onPullDownRefresh: function () {
      console.log('onPullDownRefresh');
      // 这个地方相当于初始化的操作，类似于刷新
      wx.showNavigationBarLoading();
      this.data.currentPage = 1;
      this.onQuery();
      setTimeout(() => {
      wx.hideNavigationBarLoading();
      wx.stopPullDownRefresh();
      }, 1000);

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

      if (this.data.noMoreLottery) return;
      if (this.data.querying) return;

      this.onQueryMore();

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})