// miniprogram/pages/login/login.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {
      avatarUrl: 'https://pica.zhimg.com/v2-43aeeecef2489620b09ea9c8f4ac6dad.png',
      nickName: '微信用户'
    },
    signaturePic: '',
    signatureFilePic: '',
    fileName1: '',
    fileName2: '',
    filePath1: '',
    filePath2: '',
    idx: 1,
    checked: false,
    fileitems: [
      { id: '58e7398568857a75002f0cf96cb628b7', name: 'USA', value: '《用户服务协议》' , checked: false},
      { id: '58e7398568857a75002f0cf96cb628b7', name: 'CHN', value: '《隐私政策》', checked: true },
    ],
    items: [],
    uuid: '',
    num: 0,
    name: '',
    tel: '',
    no: '',
    email: '',
    dept: '',
    date: '2024-07-01',
    branch: '',
    index: 0,
    roles: [{
      name: '普查员'
    },{
      name: '普查指导员'
    }],
    branches: [
      {"id":"00","name":"请选择"},
      {"id":"01","name":"坂田街道"},
      {"id":"02","name":"平湖街道"},
      {"id":"03","name":"布吉街道"},
      {"id":"04","name":"吉华街道"},
      {"id":"05","name":"南湾街道"},
      {"id":"06","name":"横岗街道"},
      {"id":"07","name":"园山街道"},
      {"id":"08","name":"龙城街道"},
      {"id":"09","name":"宝龙街道"},
      {"id":"10","name":"龙岗街道"},
      {"id":"11","name":"坪地街道"},
      {"id":"12","name":"龙岗区外"}
    ],
    roleindex: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    this.onGetTime();
    this.onGetOpenid();
    // this.onQuery();
    wx.getSystemInfo({
      success (res) {
        console.log(res.model)
        console.log(res.pixelRatio)
        console.log(res.windowWidth)
        console.log(res.windowHeight)
        console.log(res.language)
        console.log(res.version)
        console.log(res.platform)
        that.setData({
          windowWidth: res.windowWidth,
          windowHeight: res.windowHeight
        })

      }
    })
  },
  onQuery: function(){
    // 在小程序代码中：
    wx.cloud.callFunction({
      name: 'fetchBranches',
      data: {

      }
    })
    .then(res=>{
      console.log('callFunction fetchBranches result: ', res);
      let items = res.result.data;
      
      this.setData({
        branches: items
      })
    })
    .catch(err=>{
      console.error('[云函数] [getTime] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.setData({
      date: app.globalData.today
    })
  },
  toSign: function(){
    console.log('003');
    let url = '../signature/signature';
    wx.navigateTo({
      url: url,
      events: {
        backData: (data) => {
          console.log('签名页面返回的签名数据,图片未传到云存储，是本地临时文件路径:', data)
          //历史原因， 这个图片就是竖着的，我是存到 obs的时候旋转的图片，仓促将就用一下吧，图片是竖着的... 
          this.setData({
            signaturePic: data.tempFilePath
          })
          this.uploadFile2(data.tempFilePath);
        }
      },
    })
  },

  uploadFile2: function(tempFilePath){
    let that = this;
    wx.cloud.uploadFile({
      cloudPath: Date.now().toString() + parseInt(Math.random() * 10000) + '.png',
      filePath: tempFilePath, // 文件路径
      config: {
        env: 'cloud1-5gs4xso4fbd5e5ab'
      },
      success: res => {
        // get resource ID
        console.log(res.fileID)
        that.setData({
          signatureFilePic: res.fileID
        })

      },
      fail: err => {
        // handle error
        wx.showToast({
          title: '上传失败',
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onGetUUID();
  },
  onGetUUID: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'getUUID',
      data: {

      }
    })
    .then(res=>{
      console.log('[云函数] [getUUID]: ', res)
      that.setData({
        uuid: res.result.uuid
      })
    })
    .catch(err=>{
      console.error('[云函数] [getUUID] 调用失败', err)
      
    })
  },
  checkboxChange: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value);
    if(e.detail.value.length > 0){
      this.setData({
        checked: true
      })
    }

    if(e.detail.value.length == 0){
      this.setData({
        checked: false
      })
    }


  },
  bindNameInput: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindGradeInput: function (e) {
    this.setData({
      grade: e.detail.value
    })
  },
  bindTelInput: function (e) {
    this.setData({
      tel: e.detail.value
    })
  },
  bindMailInput: function (e) {
    this.setData({
      email: e.detail.value
    })
  },
  bindDeptInput: function (e) {
    this.setData({
      dept: e.detail.value
    })
  },
  bindNoInput: function (e) {
    this.setData({
      no: e.detail.value
    })
  },
  bindDateChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },
  bindRoleChange: function(e){
    console.log('picker branch code 发生选择改变，携带值为', e.detail.value);

    this.setData({
      roleindex: e.detail.value
    })
  },

  bindBranchChange: function(e){
    console.log('picker branch code 发生选择改变，携带值为', e.detail.value);

    this.setData({
      index: e.detail.value
    })
  },

  toTip: function(){
    let that = this;
    let tel = this.data.tel;

    if(tel.length != 11){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '请核对手机信息',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })   
      return;
    }
    
    wx.showModal({
        title: "提示",
        content: "手机号【"+tel+"】提交后不能修改，您确定吗？",
        confirmText: "确定",
        cancelText: "再想想",
        success: function(res) {
            res.confirm ? that.toGo() : console.log("再想想");
        }
    });
  },
  add: function(name,no){
    const db = wx.cloud.database();
    db.collection('account').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        name,
        no,
        updateTime: Date.now()
      }
    })
    .then(res => {
      console.log(res)

    })
    .catch((err)=>{
   
      console.log(err)
    })
  },
  validate: async function(){
    const db = wx.cloud.database()
    const res = await db.collection('user').where({
      Name: this.data.name,
      No: this.data.no
    }).count();

    console.log('[数据库] [查询记录] 成功: ', res);
    let total = res.total;

    if(total==0){
      this.add(this.data.name,this.data.no);
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '确定',
        content: '抱歉，本次活动仅限内部员工参与，感谢您的支持，谢谢！',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })   
      return;
    }else{
      this.toQueryTotal();
    }

  },
  toQueryTotal: async function(){
    const db = wx.cloud.database()
    const res = await db.collection('profiles').where({
      name: this.data.name,
      no: this.data.no
    }).count();

    console.log('[数据库] [查询记录] 成功: ', res);
    let total = res.total;
    if(total > 0){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '确定',
        content: '该工号已被注册，请核对',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      }) 
      return
    }
    this.toGo();
  },
  toGo: function(){
    let {name, no} = this.data;

    console.log(JSON.stringify(this.data));

    // let rolename = this.data.roles[this.data.roleindex]['name'];
    // let role = this.data.roleindex;

    if(this.data.checked == false){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '请先勾选协议',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })   
      return;
    }

    if(name == ''){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '请先填写姓名信息',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })   
      return;
    }

    app.globalData.userInfo = {
      name,
      no
    };

    const db = wx.cloud.database();
    db.collection('profiles').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        _id: this.data.openid,
        name,
        no,
        vote: 1,
        auth: 0,
        userInfo: this.data.userInfo,
        time: this.data.time
      }
    })
    .then(res => {
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
      this.toHome();
    })
    .catch((err)=>{
      console.log(err)
      this.toHome();
    })

  },
  toHome: function(){
    wx.reLaunch({
      url: '../home/home'
    })
  },
  // 上传图片
  doUpload: function () {
    // 选择图片
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original','compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        console.log('[选择图片] 成功：',res);

        const filePath = res.tempFilePaths[0]

        that.uploadFile(filePath);

      },
      fail: e => {
        console.error(e)
      }
    })
  },
  toNotice: function(e){
    console.log(e.target.dataset.id);
    let id = e.target.dataset.id;
    console.log('checkbox发生change事件，携带value值为：', e.detail.value);
    let url = '../notice/notice?id='+id;
    wx.navigateTo({
      url: url
    })
  },
  uploadFile: function(filePath){

    let that = this;
    
    wx.showLoading({
      title: '上传中',
    })

    let random = new Date().getTime();
    let ext = '.jpg';
    // 上传图片
    const cloudPath = `my-image-${random}${ext}`
    wx.cloud.uploadFile({
      cloudPath,
      filePath: filePath,
      config: {
        env: 'cloud1-5gs4xso4fbd5e5ab'
      },
      success: res => {
        console.log('[上传文件] 成功：', res)

        app.globalData.fileID = res.fileID;
        app.globalData.cloudPath = cloudPath;
        app.globalData.fileUrl = filePath;
        app.globalData.fileType = 'image';

        let items = this.data.items;
        items.push(res.fileID);
        let idx = this.data.idx;

        
        that.setData({
          ['fileName'+idx]: cloudPath,
          items,
          fileName: cloudPath,
          fileUrl: res.fileID,
          idx: idx + 1
        },()=>{
          that.create();

        })


      },
      fail: e => {
        console.error('[上传文件] 失败：', e)
        wx.showToast({
          icon: 'none',
          title: '上传失败',
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })

  },
  create: function(){
    const db = wx.cloud.database();
    db.collection('cards').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        action: '身份证明',
        uuid: this.data.uuid,
        name: app.globalData.name,
        fileName: this.data.fileName,
        fileUrl: this.data.fileUrl, 
        time: app.globalData.time || '',
        today: app.globalData.today || '',
        updateTime: Date.now()
      }
    })
    .then(res => {
      
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
      this.setData({
        num: this.data.num + 1
      })
    })
    .catch((err)=>{
      console.log(err)
     
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onGetTime: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'getTime',
      data: {}
    })
    .then(res=>{
      console.log('[云函数] [login]: ', res)
      that.setData({
        time: res.result.time
      })
    })
    .catch(err=>{
      console.error('[云函数] [getTime] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  onGetOpenid: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {}
    })
    .then(res=>{
      console.log('[云函数] [login]: ', res)
      that.setData({
        openid: res.result.openid
      })
    })
    .catch(err=>{
      console.error('[云函数] [login] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  }
})