// miniprogram/pages/select/select.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    max: 1,
    total: 0,
    num: 0,
    files: [],
      itemid: '',
      items: [
          {id: '01', name: '自然风光人文类', value: '01', selected: false},
          {id: '02', name: '工作纪实类', value: '02', selected: false},
          {id: '03', name: '城市交通类', value: '03', selected: false}
      ],
      itemid2: '',
      items2: [
        {id: '01', name: '单图', value: '01', selected: false},
        {id: '02', name: '组图', value: '02', selected: false}
    ],
  },
  toGo: function(){

    let that = this;
    wx.requestSubscribeMessage({
      tmplIds: ['vAQrk4NXDx7yHWt8KOFTHPx4KV10fXXlxYF43P59cRA'],
      success (res) { 
        console.log(res);
        that.doUpload();
      },
      fail (err){
        console.log(err);
        that.doUpload(); 
      }
    })
  },
  // 上传图片
  doUpload: function () {
    // 选择图片
    let that = this;
    console.log('chooseImage',this.data.max);
    wx.chooseImage({
      count: this.data.max,
      sizeType: ['original','compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        console.log('[选择图片] 成功：',res);

        const tempFilePaths = res.tempFilePaths;
        tempFilePaths.forEach(filePath=>{
          that.uploadFile(filePath);
        })


      },
      fail: e => {
        console.error(e)
      }
    })
  },
  uploadVideoFile: function(filePath){

    let that = this;
    
    wx.showLoading({
      title: '上传中',
      mask: true
    })

    let random = new Date().getTime();
    let ext = '.mp4';
    // 上传图片
    const cloudPath = `my-video-${random}${ext}`
    wx.cloud.uploadFile({
      cloudPath,
      filePath: filePath,
      config: {
        env: 'cloud1-5gs4xso4fbd5e5ab'
      },
      success: res => {
        console.log('[上传文件] 成功：', res)

        app.globalData.fileID = res.fileID
        app.globalData.cloudPath = cloudPath
        app.globalData.fileUrl = filePath;

        console.log('具体图片大小请去云开发控制台，云存储一栏查看，当前文件为：' + cloudPath)
        
        that.setData({
          fileName: cloudPath,
          fileUrl: res.fileID
        },()=>{
          that.create();
          
        })


      },
      fail: e => {
        console.error('[上传文件] 失败：', e)
        wx.showToast({
          icon: 'none',
          title: '上传失败',
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
   
  },

  uploadFile: function(filePath){

    let that = this;
    
    wx.showLoading({
      title: '上传中',
      mask: true
    })

    let random = new Date().getTime();
    let ext = '.jpg';
    // 上传图片
    const cloudPath = `my-image-${random}${ext}`
    wx.cloud.uploadFile({
      cloudPath,
      filePath: filePath,
      config: {
        env: 'cloud1-5gs4xso4fbd5e5ab'
      },
      success: res => {
        console.log('[上传文件] 成功：', res)

        app.globalData.fileID = res.fileID;
        app.globalData.cloudPath = cloudPath;
        app.globalData.fileUrl = filePath;
        app.globalData.fileType = 'image';

        let items = this.data.files;
        items.push(res.fileID);
        that.setData({
          files: items,
          fileName: cloudPath,
          fileUrl: res.fileID
        },()=>{
          that.create();

        })


      },
      fail: e => {
        console.error('[上传文件] 失败：', e)
        wx.showToast({
          icon: 'none',
          title: '上传失败',
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })

  },
  create: function(){
    let {name, dept, tel} = app.globalData;

    const db = wx.cloud.database();
    db.collection('files').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        uuid: this.data.uuid,
        name,
        dept,
        tel,
        userInfo: app.globalData.userInfo,
        fileType: 1,
        fileName: this.data.fileName,
        fileUrl: this.data.fileUrl, 
        time: app.globalData.time || '',
        today: app.globalData.today || '',
        status: false,
        updateTime: Date.now()
      }
    })
    .then(res => {
      
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
      this.setData({
        num: this.data.num + 1
      })
    })
    .catch((err)=>{
      console.log(err)
     
    })
  },
  updatePhoto: function(){

    let time = app.globalData.time;
    let today = app.globalData.today;

    let name = app.globalData.name || '';

    const db = wx.cloud.database();
    const $ = db.command.aggregate
    
    db.collection('photo').doc(this.data.uuid).update({
      // data 字段表示需新增的 JSON 数据
      data: {
        uuid: this.data.uuid,
        items: this.data.files,
        num: this.data.items.length,
        name,
        total: 0,
        today,
        time,
        updateTime: Date.now()
      }
    })
    .then(res => {
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
      
      this.toDO();

    })
    .catch((err)=>{
      console.log(err)
    })
  },
  toNext: function(){
    let that = this;
    let text = '继续投稿';
    if(this.data.total == 2){
      text = '确认';
    }
    wx.showModal({
      showCancel: true,
      title: '提示',
      confirmText: text,
      content: '作品提交成功，每人至多可投稿三个作品。',
      success (res) {
        if (res.confirm) {
          console.log('用户点击确定');
          that.toSelect();
          
        } else if (res.cancel) {
          console.log('用户点击取消')
          wx.navigateBack({
            delta: 1
          })
        }
      }
    })   
  },
  toSelect: function(){
    console.log('003');
    if(this.data.total == 2){
      wx.navigateBack({
        delta: 1
      })
      return
    }
    let url = '../select/select';
    wx.redirectTo({
      url: url
    })
  },
  notify: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'notify',
      data: {
        
      }
    })
    .then(res=>{
      console.log('[云函数] [notify]: ', res)
      
    })
    .catch(err=>{
      console.error('[云函数] [notify] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  tapSelect: function(e){
    console.log(e.currentTarget.dataset.id);
    let id = e.currentTarget.dataset.id;
    let items = this.data.items;
    items.forEach(item=>{
      item.selected = false;
      if(item.id == id){

        item.selected = true;
      }
    })

    this.setData({
      itemid: id,
      items
    })

  },
  tapSelect2: function(e){
    console.log(e.currentTarget.dataset.id);
    let id = e.currentTarget.dataset.id;
    let items2 = this.data.items2;
    items2.forEach(item=>{
      item.selected = false;
      if(item.id == id){

        item.selected = true;
      }
    })
    let max = id == '01' ? 1 : 5;
    this.setData({
      max,
      itemid2: id,
      items2
    })

  },
  radioChange: function (e) {
      console.log('radio发生change事件，携带value值为：', e.detail.value);

      var radioItems = this.data.radioItems;
      for (var i = 0, len = radioItems.length; i < len; ++i) {
          radioItems[i].checked = radioItems[i].value == e.detail.value;
      }

      this.setData({
          radioItems: radioItems,
          [`formData.radio`]: e.detail.value
      });
  },
  checkboxChange: function (e) {
      console.log('checkbox发生change事件，携带value值为：', e.detail.value);

      var checkboxItems = this.data.checkboxItems, values = e.detail.value;
      for (var i = 0, lenI = checkboxItems.length; i < lenI; ++i) {
          checkboxItems[i].checked = false;

          for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
              if(checkboxItems[i].value == values[j]){
                  checkboxItems[i].checked = true;
                  break;
              }
          }
      }

      this.setData({
          checkboxItems: checkboxItems,
          [`formData.checkbox`]: e.detail.value
      });
    },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // this.onQuery();
  },
  onQuery: function(storageCate) {
    let that = this;

    const db = wx.cloud.database()
    db.collection('category').get().then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
      let arr = res.data;
      let items = [];
      arr.forEach(element => {
        items.push({
            name: element.name,
            value: element._id
        })
      });
      this.setData({
        checkboxItems: items
      })
    })
  },

  bindFormSubmit: function(e) {

    console.log('bindFormSubmit');

    console.log(e.detail.value.title);
    console.log(e.detail.value.remark);
    let title = e.detail.value.title;
    let remark = e.detail.value.remark;

    if(title == ''){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '请先填写作品名称',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })   
      return;
    }
    if(remark == ''){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '请先填写作品说明',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })   
      return;
    }

    if(this.data.itemid == ''){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '请先选择投稿类别',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })   
      return;
    }

    this.addPhoto(title, remark)

  },
  addPhoto: function(title, remark){

    let {name, tel, dept, today, time } = app.globalData;

    let {itemid, itemid2, files} = this.data;

    const db = wx.cloud.database();
    const $ = db.command.aggregate
    
    db.collection('photo').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        _id: this.data.uuid,
        type: 1, // 1图片 2视频
        uuid: this.data.uuid,
        name,
        dept,
        tel,
        items: files,
        itemid,
        itemid2,
        title,
        remark,
        today,
        time,
        updateTime: Date.now()
      }
    })
    .then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
      this.toNext();
      this.notify();

    })
    .catch((err)=>{
      console.log(err)
    })
  },
  toFile: function(){
    console.log('003');
    let url = '../file/file?uuid='+this.data.uuid;
    wx.navigateTo({
      url: url
    })
  },
  complete: function(){
    var checkboxItems = this.data.checkboxItems;
    let selected = [];
    checkboxItems.forEach(item=>{
        if(item.checked){
            selected.push(item.value)
        }
    })
    console.log(selected);
    app.globalData.selected = selected;

    if(selected.length == 0){
      wx.showToast({
        icon:'loading',
        title: '请选择题库',
      })
      return
    }
    wx.navigateTo({
        url: '../somecode/somecode',
    })
  },
  toType: function(){
    wx.navigateTo({
      url: '../type/type',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.onGetUUID();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    this.onQueryTotal();
  },
  onQueryTotal: function(){
    const db = wx.cloud.database()
    db.collection('photo').where({
      _openid: app.globalData.openid,
      type: 1
    }).count().then(res=>{
      console.log('[数据库] [查询记录] 成功: ', res);
      let total = res.total;
      this.setData({
        total: res.total
      })

      if(total >= 3){
        wx.showModal({
          showCancel: false,
          title: '提示',
          confirmText: '我知道了',
          content: '您已达到投稿上限',
          success (res) {
            if (res.confirm) {
              console.log('用户点击确定')
              wx.navigateBack({
                delta: 1
              })
              
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })  
      }

    });
  },
  onGetUUID: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'getUUID',
      data: {

      }
    })
    .then(res=>{
      console.log('[云函数] [getUUID]: ', res)
      that.setData({
        uuid: res.result.uuid
      })
    })
    .catch(err=>{
      console.error('[云函数] [getUUID] 调用失败', err)
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})