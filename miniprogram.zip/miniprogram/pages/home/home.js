// miniprogram/pages/home/home.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    total: 0,
    message: '欢迎参加本次活动',
    indicatorDots: true,
    vertical: false,
    autoplay: false,
    circular: false,
    interval: 2000,
    duration: 500,
    previousMargin: 0,
    nextMargin: 0,
    image: 'https://picx.zhimg.com/v2-0e92cf72712866eb2c7acdf653e91cc1.png',
    images: [
      'http://file.xiaomutong.com.cn/img2020092708.png',
      'http://file.xiaomutong.com.cn/img2020092704.png'
    ],
    items: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(app.globalData);
    let that = this;
    wx.getSystemInfo({
      success (res) {
        console.log(res.model)
        console.log(res.pixelRatio)
        console.log(res.windowWidth)
        console.log(res.windowHeight)
        console.log(res.language)
        console.log(res.version)
        console.log(res.platform)
        that.setData({
          windowWidth: res.windowWidth,
          windowHeight: res.windowHeight
        })

      }
    })

    this.onGetTime();
    this.onQueryNotice();
  },
  onQuery: async function(){
    let _id = this.data.openid;

    const db = wx.cloud.database()
    const _ = db.command
    const res = await db.collection('profiles').where({
      _openid: this.data.openid
    }).count();
    console.log(res);
    let total = res.total;
    if(total == 0){
      return
    }

    db.collection('profiles').doc(_id)
    .get()
    .then(res=>{
      console.log('[数据库] [查询记录] 成功: ', res);
      let {name, tel, dept} = res.data;
      app.globalData.name = name;
      app.globalData.tel = tel;
      app.globalData.dept = dept;
    })
    .catch(err=>{
      console.error('[数据库] [查询记录] 失败：', err)
      // wx.showToast({
      //   icon: 'none',
      //   title: '查询记录失败'
      // })
    })
  },

  onQueryNotice: function(){
    const db = wx.cloud.database()
    db.collection('notice').doc('c42c9d1b68030426016b90f2512cee1a')
    .get()
    .then(res=>{
      console.log('[数据库] [查询记录] 成功: ', res);
      let data = res.data
      this.setData({
        message: data.message
      },()=>{

      })
    })
    .catch(err=>{
      console.error('[数据库] [查询记录] 失败：', err)
      
    })
  },
  onGetOpenid: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        let openid = res.result.openid;
        app.globalData.openid = openid;
        this.setData({
          openid
        },()=>{
          this.onQueryTotal();
          this.onQuery();
        })
       
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
       
      }
    })
  },
  onQueryTotal: function(){
    const db = wx.cloud.database()
    db.collection('photo').where({
      _openid: app.globalData.openid
    }).count().then(res=>{
      console.log('[数据库] [查询记录] 成功: ', res);
      this.setData({
        total: res.total
      })
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onGetOpenid();
    this.setData({
      role: app.globalData.userInfo.role,
      openid: app.globalData.openid,
      today: app.globalData.today
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: "东部力量·心路护航",
      path: "pages/welcome/welcome",
      imageUrl: app.globalData.shareImage
    };
  },
  goHistory: function(){
    let url = '/pages/history/history';
    wx.navigateTo({
      url: url
    })
  },

  zuheGo: function(){
    let url = '/pages/zuhehome/zuhehome';
    wx.navigateTo({
      url: url
    })
  },

  biaozhGo: function(){
    let url = '/pages/biaozhunselect/biaozhunselect';
    wx.navigateTo({
      url: url
    })
  },
  itemGo: function(){
    let url = '/pages/items/items';
    wx.navigateTo({
      url: url
    })
  },

  someviewGo: function(){
    let url = '/pages/someview/someview';
    wx.navigateTo({
      url: url
    })
  },
  assoGo: function(){
    let url = '/pages/asso/asso';
    wx.navigateTo({
      url: url
    })
  },
  goHelp: function(){
    let url = '/pages/help/help';
    wx.navigateTo({
      url: url
    })
  },
  bindgorank: function(){
    let url = '/pages/rank/rank';
    wx.navigateTo({
      url: url
    })
  },
  goSequence: function(){
    let url = '/pages/sequence/sequence';
    wx.navigateTo({
      url: url
    })
  },
  goRandom: function(){
    let url = '/pages/random/random';
    wx.navigateTo({
      url: url
    })
  },
  goTwo: function(){
    let url = '/pages/two/two';
    wx.navigateTo({
      url: url
    })
  },
  goThree: function(){
    let url = '/pages/examhome/examhome';
    wx.navigateTo({
      url: url
    })
  },
  bindgoabout: function(){
    let url = '/pages/about/index';
    wx.navigateTo({
      url: url
    })
  },
  goExam: function(){

    let url = '/pages/treeselect/treeselect?mode=1';
    wx.navigateTo({
      url: url
    })
    return;

    

  },
  
  aboutGo: function(){
    let url = '/pages/about/about';
    wx.navigateTo({
      url: url
    })
  },
  goSix: function(){
    let url = '/pages/six/six';
    wx.navigateTo({
      url: url
    })
  },
  goTpl: function(){
    let url = '/pages/template/template';
    wx.navigateTo({
      url: url
    })
  },
  toVote: async function(){
    console.log('toVote');
    const db = wx.cloud.database()
    const _ = db.command
    const res = await db.collection('profiles').where({
    _openid: app.globalData.openid
    }).count();

    console.log(res);
    let total = res.total;
    if(total == 0){
        let url = '/pages/login/login';
        wx.reLaunch({
            url: url
        })
        return;
    }

    this.onQueryVoteItems();
  },
  onQueryVoteItems: function(){
    console.log('onQueryVoteItems');

    wx.showLoading({
      title: '跳转中',
    })

    // 调用云函数
    let that = this;
    let map = app.globalData.map;
    wx.cloud.callFunction({
    name: 'fetchVote',
    data: {
        
    }
    })
    .then(res => {
      console.log('[云函数] [fetchVote]: ', res)
      let list = res.result.data;
      let items = [];
      list.forEach(element => {
        items.push(element.voteid);
        map[element.itemid]++;
      });

      app.globalData.voteItems = items;
      console.log(JSON.stringify(items));

      app.globalData.map = map;
      console.log(JSON.stringify(map));
      this.vote();
    
    }).catch(err => {
      console.error('[云函数] [fetchVote] 调用失败', err)

    })
  },
  vote: function () {

    wx.hideLoading()
    let url = '/pages/vote/vote';
    wx.navigateTo({
      url: url
    })
    return;

  },
  toArticle: function (e) {
    wx.navigateTo({
      url: '/pages/article/article?id=c42c9d1b67f921d500f042e4155d4ea3',
    })
  },
  toAlbum: function(){
    wx.navigateTo({
      url: '/pages/album/album',
    })
  },
  toHint: function(){
    wx.navigateTo({
      url: '/pages/hint/hint',
    })
  },
  toGo: function(){

    this.toHint();
    return;

    let that = this;
    wx.requestSubscribeMessage({
      tmplIds: ['RhBRM6ikjPjFMYlTB5AmbF-NOB5HXrpzGl4Lu3hm26E'],
      success (res) { 
        //console.log(res);
        that.toCheckTotal();
      },
      fail (err){

        that.toCheckTotal(); 
      }
    })
  },
  toCheckTotal: function(){
    if(this.data.total >= 3){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '您已达到投稿上限',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })  
      return;
    }
    this.toSelect();
  },
  toSelect: async function(){
    const db = wx.cloud.database()
    const _ = db.command
    const res = await db.collection('profiles').where({
    _openid: this.data.openid
    }).count();
    console.log(res);
    let total = res.total;
    if(total == 0){
        let url = '/pages/login/login';
        wx.reLaunch({
            url: url
        })
        return;
    }

    wx.navigateTo({
      url: '/pages/choose/choose',
    })
  },
  onTapFile: async function (e) {
    
    const db = wx.cloud.database()
    const _ = db.command
    const res = await db.collection('profiles').where({
    _openid: this.data.openid
    }).count();
    console.log(res);
    let total = res.total;
    if(total == 0){
        let url = '/pages/login/login';
        wx.reLaunch({
            url: url
        })
        return;
    }
    this.toFile();

  },
  onTapInfo: function(){
    console.log('003');
    let url = '../meinfo/meinfo';
    wx.navigateTo({
      url: url
    })
  },
  toFile: function(){
    console.log('003');
    let url = '../file/file';
    wx.navigateTo({
      url: url
    })
  },
  toPhoto: function(){
    // wx.showModal({
    //   showCancel: false,
    //   title: '提示',
    //   confirmText: '我知道了',
    //   content: '功能尚未开放',
    //   success (res) {
    //     if (res.confirm) {
    //       console.log('用户点击确定')
    //     } else if (res.cancel) {
    //       console.log('用户点击取消')
    //     }
    //   }
    // }) 
    // return
    
    let url = '../photo/photo';
    wx.navigateTo({
      url: url
    })
  },
  rankGo: function(){
    console.log('003');
    let url = '../rank/rank';
    wx.navigateTo({
      url: url
    })
  },
  toMy: async function(){
    const db = wx.cloud.database()
    const _ = db.command
    const res = await db.collection('profiles').where({
    _openid: this.data.openid
    }).count();
    console.log(res);
    let total = res.total;
    if(total == 0){
        let url = '/pages/login/login';
        wx.navigateTo({
            url: url
        })
        return;
    }

    const res2 = await db.collection('profiles').where({
      _openid: this.data.openid,
      auth: 1
      }).count();
      console.log(res2);
      total = res2.total;
      if(total == 0){
          let url = '/pages/wechat/wechat';
          wx.navigateTo({
              url: url
          })
          return;
      }

    let url = '../my/my';
    wx.navigateTo({
      url: url
    })
  },
  noteGo: async function (e) {
    

    wx.navigateTo({
      url: '/pages/note/note?id=003',
    })

  },
  articleGo: function (e) {
    wx.navigateTo({
      url: "/pages/article/article",
    })
  }, 
  exportGo: function(){
    let url = '/pages/export/export';
    wx.navigateTo({
      url: url
    })
  },
  fileGo: function(){
    let url = '/pages/file/file';
    wx.navigateTo({
      url: url
    })
  },
  pdfGo: function(){
    let url = '/pages/folder/folder';
    wx.navigateTo({
      url: url
    })
  },
  kefuGo: function(){
    let url = '/pages/kefu/kefu';
    wx.switchTab({
      url: url
    })
  },
  historyGo: async function (e) {
    wx.navigateTo({
      url: "/pages/history/history",
    })
  },
  somecodeGo: function(){
    wx.navigateTo({
      url: "/pages/somecode/somecode",
    })
  },
  rolesGo: function(){
    wx.navigateTo({
      url: "/pages/roles/roles",
    })
  },
  rankGo: function (e) {
    wx.navigateTo({
      url: '/pages/rank/rank?id=003',
    })
  },
  aboutGo: function (e) {
    wx.navigateTo({
      url: '/pages/about/about',
    })
  },
  onGetTime: function() {
    // 调用云函数
    let that = this;
    wx.cloud.callFunction({
      name: 'getTime',
      data: {

      }
    })
    .then(res => {
      console.log('[云函数] [getTime]: ', res)
      let {today, time} = res.result;
      app.globalData.today = today;
      app.globalData.time = time;
      
    }).catch(err => {
      console.error('[云函数] [login] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  }
})