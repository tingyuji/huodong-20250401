// pages/pic/pic.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    images: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.onQuery();
  },
  onQuery: function(){
    let _openid = app.globalData.openid;
    const db = wx.cloud.database()
    db.collection('files').where({
      _openid: _openid
    })
    .orderBy('time', 'desc')
    .get()
    .then(res=>{
      console.log('[数据库] [查询记录] 成功: ', res);
      let items = res.data;
      let images = items.map(item=>{
        return item.fileUrl;
      })
      
      this.setData({
        items,
        images
      },()=>{
        wx.hideLoading()
      });
    })
    .catch(err=>{
      console.error('[数据库] [查询记录] 失败：', err)
      wx.showToast({
        icon: 'none',
        title: '查询记录失败'
      })
      
    })
  },
  preview(){
    let image = this.data.images[0];
    wx.previewImage({
      current: image, // 当前显示图片的http链接
      urls: this.data.images // 需要预览的图片http链接列表
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})