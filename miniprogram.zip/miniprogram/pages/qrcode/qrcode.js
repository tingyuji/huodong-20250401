var t = getApp()

Page({
    data: {
        vote: {},
        cordPath: "",
        canvasHeight: 750,
        bottomInfoHeight: 350,
        canvasDom: null,
        canvas: null,
        ctx: null,
        dpr: 1
    },
    onLoad: function(options) {
        this.setData({
            id: options.id
        },()=>{
            this.onQuery();
        })
    },
    onQuery: function(){
        let that = this;
  
        const db = wx.cloud.database()
        db.collection('photo')
        .doc(this.data.id)
        .get()
        .then(res => {
          console.log('[数据库] [查询记录] 成功: ', res)
          let vote = res.data;
          vote.name = '';
  
          this.setData({
            'vote': vote
          },()=>{
              this.drawImage();
          })
  
        })
        .catch(err=>{
          console.error('[数据库] [查询记录] 失败：', err)
          wx.showToast({
            icon: 'none',
            title: '查询记录失败'
          })
          
        })
      },
    drawText: function() {
        var t = 20, a = this.data.canvasWidth / 2;
        this.data.ctx.save(), this.data.ctx.font = "bold 20px Arial", this.data.ctx.fillStyle = "#000", 
        this.data.ctx.textAlign = "center";
        var e = this.data.ctx.measureText(this.data.vote.name);
        if (e.width > this.data.canvasWidth - 40) {
            e.width > 2 * (this.data.canvasWidth - 40) && (this.data.vote.title = this.data.vote.title.substring(0, 32));
            t = this.data.posterHeight + t, this.data.ctx.fillText(this.data.vote.title.substring(0, 18), a, t), 
            t += 30, this.data.ctx.fillText(this.data.vote.title.substring(18, this.data.vote.title.length), a, t);
        } else t = this.data.posterHeight + t, this.data.ctx.fillText(this.data.vote.name, a, t);
        this.data.vote.title && (this.data.vote.title.length > 20 && (this.data.vote.title = this.data.vote.title.substring(0, 20)), 
        this.data.ctx.font = "bold 16px Arial", this.data.ctx.fillStyle = "#ebbe28", t += 30, 
        this.data.ctx.fillText(this.data.vote.title, a, t));
        this.data.ctx.restore();
    },
    drawImage: function() {
        var t = this;
        wx.createSelectorQuery().select("#notes").fields({
            node: !0,
            size: !0
        }).exec(function(a) {
            var e = a[0], i = e.node;
            if (i && i.getContext) {
                var o = i.getContext("2d"), n = wx.getSystemInfoSync().pixelRatio;
                t.setData({
                    canvasDom: e,
                    canvas: i,
                    ctx: o,
                    dpr: n
                }, function() {
                    this.drawing();
                });
            } else wx.showModal({
                title: "提示",
                content: "请在手机端生成分享海报",
                showCancel: !1,
                success: function(t) {
                    wx.navigateBack({
                        delta: 1
                    });
                }
            });
        });
    },
    drawing: function() {
        var t = this;
        wx.showLoading({
            title: "生成中",
            mask: !0
        }), t.drawPoster().then(function() {
            t.drawText(), t.drawQrcode();
        });
    },
    drawPoster: function() {
        var a = this;
        return new Promise(function(e, i) {
            var o = a.data.canvas.createImage();
            a.data.vote.cover_pro = a.data.vote.cover_pro || {}, o.src = a.data.vote.cover_pro.path || t.globalData.shareImg02, 
            o.onload = function() {
                a.computeCanvasSize(o.width, o.height).then(function(t) {
                    a.data.ctx.save(), a.data.ctx.fillStyle = "#ffffff", a.data.ctx.fillRect(0, 0, a.data.canvasWidth, a.data.canvasHeight), 
                    a.data.ctx.restore(), a.data.ctx.drawImage(o, 0, 0, o.width, o.height, 10, 10, t.width, t.height), 
                    e();
                });
            };
        });
    },
    drawImg: function() {
        var t = this, a = t.data.canvas.createImage();
        a.src = t.data.vote.imgs[0].path, a.onload = function() {
            t.data.ctx.save(), t.data.ctx.drawImage(a, 0, 0, 100, 150, 20, 300, 100, 100), t.data.ctx.restore();
        };
    },
    drawQrcode: function() {
        var t = this, a = t.data.posterHeight + 130, e = 150, i = t.data.canvas.createImage();
        var o = {
            scene: t.data.vote._id,
            page: "pages/welcome/welcome",
            width: 180,
            is_hyaline: !0
        };
        // i.src = 'https://picx.zhimg.com/v2-9f4e46b8c45ec71d2ae7f7db100ed4fe.jpeg';
        // i.src = `cloud://cloud1-0gpl3oof20ee43c4.636c-cloud1-0gpl3oof20ee43c4-1314720130/${this.data.id}.png`;
        i.src = `https://636c-cloud1-5gs4xso4fbd5e5ab-1314720130.tcb.qcloud.la/${this.data.id}.png`;
        i.onload = function() {
            t.data.ctx.save(), t.data.ctx.drawImage(i, 0, 0, i.width, i.height, (t.data.canvasWidth - e) / 2, a, e, e), 
            t.data.ctx.font = "14px Arial", t.data.ctx.fillStyle = "#40c572", t.data.ctx.textAlign = "center", 
            a = a + e + 20, t.data.ctx.fillText("长按识别二维码进入投票", t.data.canvasWidth / 2, a), t.data.ctx.restore(), 
            wx.hideLoading();
        };
    },
    computeCanvasSize: function(t, a) {
        var e = this;
        return a > 2e3 && (a = 2e3), new Promise(function(i, o) {
            var n = e.data.canvasDom.width, d = n * (a / t), s = d + e.data.bottomInfoHeight;
            e.setData({
                canvasWidth: n,
                canvasHeight: s,
                posterHeight: d
            }, function() {
                e.data.canvas.width = e.data.canvasWidth * e.data.dpr, e.data.canvas.height = s * e.data.dpr, 
                e.data.ctx.scale(e.data.dpr, e.data.dpr), setTimeout(function() {
                    i({
                        width: n - 20,
                        height: d - 20
                    });
                }, 1200);
            });
        });
    },
    savePoster: function() {
        var t = this;
        wx.showModal({
            title: "提示",
            content: "是否保存图片到手机？",
            success: function(a) {
                a.confirm && wx.canvasToTempFilePath({
                    canvas: t.data.canvas,
                    fileType: "jpg",
                    success: function(t) {
                        wx.saveImageToPhotosAlbum({
                            filePath: t.tempFilePath,
                            success: function(t) {
                                wx.hideLoading(), wx.showToast({
                                    title: "保存成功"
                                });
                            },
                            fail: function() {
                                wx.hideLoading();
                            }
                        });
                    }
                });
            }
        });
    }
});