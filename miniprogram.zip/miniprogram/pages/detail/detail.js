// pages/pic/pic.js
var app = getApp();
import EventEmitter from '../../eventEmitter.js';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    vote: false,
    title: '',
    remark: '',
    images: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(JSON.stringify(options));

    let {id, itemid} = options;
    
    this.setData({
      id,
      itemid
    },()=>{
      this.onQuery();
      this.onQueryVoteItems();
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    
    

    this.update();
    this.onMakeQrcode();

  },
  onMakeQrcode: function(){

    // 调用云函数
    let that = this;
    wx.cloud.callFunction({
    name: 'qrcode',
    data: {
        id: this.data.id
    }
    })
    .then(res => {
      console.log('[云函数] [qrcode]: ', res)
    
    }).catch(err => {
      console.error('[云函数] [qrcode] 调用失败', err)

    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
   
  },
  toQrcode: function(){
    wx.navigateTo({
      url: '/pages/qrcode/qrcode?id='+this.data.id,
    })
  },
  onQueryVoteItems: function(itemid){
    // 调用云函数
    let map = {
      '01': 0,
      '02': 0,
      '03': 0
    };

    let that = this;
    wx.cloud.callFunction({
    name: 'fetchVote',
    data: {
        
    }
    })
    .then(res => {
      console.log('[云函数] [fetchVote]: ', res)
      let list = res.result.data;
      let items = [];
      list.forEach(element => {
        items.push(element.voteid);
      });

      list.forEach(element => {
        items.push(element.voteid);
        map[element.itemid]++;
      });
      app.globalData.map = map;


      let id = this.data.id;
      let vote = items.indexOf(id) != -1;
      this.setData({
        vote
      })
    
    }).catch(err => {
      console.error('[云函数] [fetchVote] 调用失败', err)

    })
  },
  update: function(){
        
    const db = wx.cloud.database();
    const _ = db.command;

    let _id = '6a580dc96803059e016c8f511ce41621';
    db.collection('voteinfo').doc(_id).update({
      // data 字段表示需新增的 JSON 数据
      data: {
        view: _.inc(1)
      }
    })
    .then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
    })
    .catch((err)=>{
      console.log(err)
    })
  },
  update2: function(){
    const myEmitter = app.globalData.myEmitter;

    const db = wx.cloud.database();
    const _ = db.command;

    let _id = '6a580dc96803059e016c8f511ce41621';
    db.collection('voteinfo').doc(_id).update({
      // data 字段表示需新增的 JSON 数据
      data: {
        total: _.inc(10)
      }
    })
    .then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
      myEmitter.emit('someEvent');
    })
    .catch((err)=>{
      console.log(err)
    })
  },
  vote: function(){

    
    // 调用云函数
    let that = this;
    wx.cloud.callFunction({
    name: 'vote',
    data: {
        id: this.data.id
    }
    })
    .then(res => {
      console.log('[云函数] [vote]: ', res)
      this.setData({
        vote: true
      })
      wx.hideLoading()
      this.update2();
      this.onQueryVoteItems();
      wx.showToast({
        title: "投票成功",
        icon: "none",
        duration: 2e3
        });
    
    }).catch(err => {
      console.error('[云函数] [vote] 调用失败', err)

    })
  },
  notify: function(){
    wx.showModal({
      showCancel: false,
      title: '提示',
      confirmText: '我知道了',
      content: '网络投票已截止，感谢您的参与！',
      success (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })  
  },
  toGo: function(){
    let map = app.globalData.map;
    console.log(JSON.stringify(map));

    let itemid = this.data.itemid;
    
    if(map[itemid] >= 3){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '当前类型作品投票已达上限',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
            
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })  
      return
    }

    // 调用云函数
    wx.showLoading({
      title: '投票中',
    })

    let that = this;
    wx.cloud.callFunction({
    name: 'add',
    data: {
      id: this.data.id,
      itemid: this.data.itemid
    }
    })
    .then(res => {
      console.log('[云函数] [add]: ', res)
      this.vote();
    
    }).catch(err => {
      console.error('[云函数] [add] 调用失败', err)
      wx.hideLoading()

    })
  },
  onQuery: function(){
    let _openid = app.globalData.openid;
    const db = wx.cloud.database()
    db.collection('photo').doc(this.data.id)
    .get()
    .then(res=>{
      console.log('[数据库] [查询记录] 成功: ', res);
      let {uuid, itemid, name, title, items, remark} = res.data;
      
      this.setData({
        uuid,
        itemid,
        name,
        items: items,
        title,
        remark
      },()=>{
        wx.hideLoading()
      });
    })
    .catch(err=>{
      console.error('[数据库] [查询记录] 失败：', err)
      wx.showToast({
        icon: 'none',
        title: '查询记录失败'
      })
      
    })
  },
  _vote(){
      let that = this;
  
      let {message} = this.data;
      const db = wx.cloud.database()
      db.collection('votes').add({
        data: {
          itemid: this.data.id,
          message
        }
      })
      .then(res=>{
        console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
        this.updateTotal();
        wx.showToast({
          icon: 'none',
          title: '投票成功'
        })
      })
      .catch(err=>{
        console.error('[数据库] [新增记录] 失败：', err)
        wx.showToast({
          icon: 'none',
          title: '新增记录失败'
        })
      })
  
  },
  updateTotal: function(){
   const db = wx.cloud.database();
   const _ = db.command;
   db.collection('photo').doc(this.data.id).update({
     // data 字段表示需新增的 JSON 数据
     data: {
       total: _.inc(10),
       updateTime: Date.now()
     }
   })
   .then(res => {
     console.log(res)
     console.log('[数据库] [查询记录] 成功: ', res);

   })
   .catch((err)=>{
     console.log(err)
   })
 },
  preview(){
    let image = this.data.items;
    wx.previewImage({
      current: image, // 当前显示图片的http链接
      urls: this.data.items // 需要预览的图片http链接列表
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
   onShareAppMessage: function () {
    let {id, itemid, name} = this.data;
    return {
      title: `快来给Ta投一票吧`,
      path: `/pages/welcome/welcome?id=${id}&itemid=${itemid}`,
      imageUrl: app.globalData.shareImage
    };
  }
})