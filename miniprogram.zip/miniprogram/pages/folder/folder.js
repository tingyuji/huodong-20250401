// pages/category/category.js
var app = getApp();
let md5 = require('../../utils/md5.js').md5;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    selectedCate:'',
    cateList: [],
    cattext:'',
    loading:!1,
    storageCate:''
  },
  handleChange({ detail = {} }) {
    console.log(detail)
    this.setData({
      current: detail.value
    },()=>{

    });
  },
  onLoad: function (options) {
    console.log('app.globalData',app.globalData);
    this.setData({
      mode: options.mode
    })
    this.onQuery();
  },
  onQuery: function(storageCate) {
    let that = this;
    let selectedItems = app.globalData.selectedItems;

    const db = wx.cloud.database()
    db.collection('folder').get().then(res => {
      console.log('[数据库] [查询记录] 成功: ', res);
      let arr = res.data;
      // let newArr = arr.filter(item => selectedItems.indexOf(item._id) != -1);
      let newArr = arr;
      let objs = {

      };
      newArr.forEach(element => {
        console.log(md5(element.name));
        objs[md5(element.name)] = element;
      });
      that.setData({
        objs,
        cateList: newArr
      })
    })
  },
  onReady: function () {

  },

  onShow: function () {
    
  },

  tapto:function(t){
    var that = this;
    if(that.data.current == ''){
      wx.showToast({
        icon:'loading',
        title: '请选择文件夹',
      })
      return
    }

    let key = md5(that.data.current);
    console.log(key);
    console.log(this.data.objs);
    let folder = this.data.objs[key];
    console.log(app.globalData);
    app.globalData.folder = folder;
    
    let url = '/pages/pdffile/pdffile?id=' + app.globalData.folder._id;
    wx.navigateTo({
      url: url,
    })
  },
  goToLianxi: function(){

    let url = '/pages/lianxihome/lianxihome?id=' + app.globalData.category._id;
    wx.navigateTo({
      url: url,
    })
  },
  goToExam: function(){

    wx.showLoading({
      title: '加载中',
    })

    // 调用云函数
    let that = this;
    wx.cloud.callFunction({
      name: 'getExam',
      data: {

      }
    })
    .then(res => {
      wx.hideLoading()
      console.log('[云函数] [getExam]: ', res)
      let time = res.result.time;
      let num = Date.parse(new Date(time.replace(/-/g, '/')));
      
      let time1 = res.result.time1;
      let num1 = Date.parse(new Date(time1.replace(/-/g, '/')));

      let time2 = res.result.time2;
      let num2 = Date.parse(new Date(time2.replace(/-/g, '/')));

      if(num < num1){
        wx.showModal({
          showCancel: false,
          title: '提示',
          confirmText: '我知道了',
          content: '考试还未开始，请耐心等待',
          success (res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })   
      }else if(num > num1 && num < num2){
        this.toExam();
      }else if(num > num2){
        wx.showModal({
          showCancel: false,
          title: '提示',
          confirmText: '我知道了',
          content: '考试已结束，谢谢参与',
          success (res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })   
      }

      
    }).catch(err => {
      console.error('[云函数] [getExam] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  toExam: async function(){

    const db = wx.cloud.database()
    const res = await db.collection('historys').where({
      _openid: this.data.openid,
      examid: app.globalData.category._id
    }).count();
    if(res.total >= 100){
      wx.showModal({
        title: '提示',
        showCancel: false,
        content: '每天只有100次答题机会',
        confirmText: '我知道了',
        success (res) {
          wx.hideLoading()
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      return;
    }

    let url = '/pages/examhome/examhome?id=' + app.globalData.category._id;
    wx.navigateTo({
      url: url
    })

  },
  goHome: function () {
    wx.switchTab({
      url: "../index/index"
    })
  }
})