// pages/xuexi/xuexi.js
var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    num: 0,
    items: [],
    itemid: ''

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(app.globalData);
    this.setData({
      uuid: options.uuid
    })
  },
  bindFormSubmit: function(e) {
    let num = this.data.num;
    if(num == 0){
      wx.showModal({
        showCancel: false,
        title: '提示',
        confirmText: '我知道了',
        content: '请先上传作品',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定');
            
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })   
      return
    }

    this.updatePhoto()

  },
  toDO: function(){
    wx.showModal({
      showCancel: false,
      title: '提示',
      confirmText: '我知道了',
      content: '已提交成功',
      success (res) {
        if (res.confirm) {
          console.log('用户点击确定');
          wx.navigateBack({
            delta: 2
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })   
  },
  uploadFile: function(filePath){

    let that = this;
    
    wx.showLoading({
      title: '上传中',
    })

    let random = new Date().getTime();
    let ext = '.jpg';
    // 上传图片
    const cloudPath = `my-image-${random}${ext}`
    wx.cloud.uploadFile({
      cloudPath,
      filePath: filePath,
      config: {
        env: 'cloud1-0gpl3oof20ee43c4'
      },
      success: res => {
        console.log('[上传文件] 成功：', res)

        app.globalData.fileID = res.fileID;
        app.globalData.cloudPath = cloudPath;
        app.globalData.fileUrl = filePath;
        app.globalData.fileType = 'image';

        let items = this.data.items;
        items.push(res.fileID);
        that.setData({
          items,
          fileName: cloudPath,
          fileUrl: res.fileID
        },()=>{
          that.create();

        })


      },
      fail: e => {
        console.error('[上传文件] 失败：', e)
        wx.showToast({
          icon: 'none',
          title: '上传失败',
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })

  },
  create: function(){
    const db = wx.cloud.database();
    db.collection('files').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        action: '学习强国',
        uuid: this.data.uuid,
        name: app.globalData.name,
        userInfo: app.globalData.userInfo,
        fileName: this.data.fileName,
        fileUrl: this.data.fileUrl, 
        time: app.globalData.time || '',
        today: app.globalData.today || '',
        status: false,
        updateTime: Date.now()
      }
    })
    .then(res => {
      
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
      this.setData({
        num: this.data.num + 1
      })
    })
    .catch((err)=>{
      console.log(err)
     
    })
  },
  updatePhoto: function(){

    let time = app.globalData.time;
    let today = app.globalData.today;

    let name = app.globalData.name || '';

    const db = wx.cloud.database();
    const $ = db.command.aggregate
    
    db.collection('photo').doc(this.data.uuid).update({
      // data 字段表示需新增的 JSON 数据
      data: {
        uuid: this.data.uuid,
        items: this.data.items,
        num: this.data.items.length,
        name,
        total: 0,
        today,
        time,
        updateTime: Date.now()
      }
    })
    .then(res => {
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
      this.notify();
      this.toDO();

    })
    .catch((err)=>{
      console.log(err)
    })
  },
  update: function(){

    let num = 40;
      
      const db = wx.cloud.database();
      const _ = db.command;

      let _id = app.globalData.openid;
      db.collection('profiles').doc(_id).update({
        // data 字段表示需新增的 JSON 数据
        data: {
          num: _.inc(num)
        }
      })
      .then(res => {
        console.log(res)
        console.log('[数据库] [查询记录] 成功: ', res);
        this.toDO();
      })
      .catch((err)=>{
        console.log(err)
      })
  },
  choosepic1: function () {
    var that = this;

    wx.chooseImage({
      count: 1,
      success:function(res){
        wx.showLoading({
          title: '处理中',
        })
        // wx.showToast({
        //   title: '正在上传...',
        //   icon: 'loading',
        //   mask: true,
        //   duration: 1000
        // }) 
        console.log(res);
        let tempFilePaths =res.tempFilePaths;
        let tempFiles = res.tempFiles;

        wx.getFileSystemManager().readFile({
          filePath: res.tempFilePaths[0],
          encoding: "base64",
          success: (res) => {
              

              wx.cloud.callFunction({
                  name: "imgSecCheck",
                  data: {
                      base64: res.data,
                  }
              }).then((res) => {
                  console.log('imgSecCheck =', res)
                  
                  setTimeout(function () {
                    wx.hideLoading()
                  }, 2000)

                  
                  if(res.result.result){
                    that.uploadFile(tempFiles[0]['path'])

                    var image = that.data.image1;
                    image.splice(0, 1);
                    that.setData({
                      image1: image
                    })
                    that.setData({
                      image1: that.data.image1.concat(tempFilePaths),
                    });
                  }

                  if(res.result.error){
                    wx.showModal({
                      showCancel: false,
                      title: '提示',
                      confirmText: '我知道了',
                      content: '内容含有违法违规内容',
                      success (res) {
                        if (res.confirm) {
                          console.log('用户点击确定')
                      
                        } else if (res.cancel) {
                          console.log('用户点击取消')
                        }
                      }
                    }) 
                    
                  }
              })
          }
        });

        


      }
    })
  },
  toGo: function(){

    let that = this;
    wx.requestSubscribeMessage({
      tmplIds: ['vAQrk4NXDx7yHWt8KOFTHPx4KV10fXXlxYF43P59cRA'],
      success (res) { 
        console.log(res);
        that.doUpload();
      },
      fail (err){
        console.log(err);
        that.doUpload(); 
      }
    })
  },
  // 上传图片
  doUpload: function () {
    // 选择图片
    let that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original','compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        console.log('[选择图片] 成功：',res);

        const filePath = res.tempFilePaths[0]

        that.uploadFile(filePath);
        
        return;

        console.log(res);
        let tempFilePaths =res.tempFilePaths;
        let tempFiles = res.tempFiles;

        wx.getFileSystemManager().readFile({
          filePath: res.tempFilePaths[0],
          encoding: "base64",
          success: (res) => {
              
          
              wx.cloud.callFunction({
                  name: "imgSecCheck",
                  data: {
                      base64: res.data,
                  }
              }).then((res) => {
                  console.log('imgSecCheck =', res)
                  
                  setTimeout(function () {
                    wx.hideLoading()
                  }, 2000)

                  
                  if(res.result.result){
                    that.uploadFile(filePath);
                  }

                  if(res.result.error){
                    wx.showModal({
                      showCancel: false,
                      title: '提示',
                      confirmText: '我知道了',
                      content: '内容含有违法违规内容',
                      success (res) {
                        if (res.confirm) {
                          console.log('用户点击确定')
                      
                        } else if (res.cancel) {
                          console.log('用户点击取消')
                        }
                      }
                    }) 
                    
                  }
              })
              .catch(err=>{
                console.log(error);
                wx.showToast({
                  title: '图片太大，请重试',
                  icon: 'success',
                  duration: 2000
                })
                
              })
          }
        });

        

      

      },
      fail: e => {
        console.error(e)
      }
    })
  },
  uploadVideoFile: function(filePath){

    let that = this;
    
    wx.showLoading({
      title: '上传中',
    })

    let random = new Date().getTime();
    let ext = '.mp4';
    // 上传图片
    const cloudPath = `my-video-${random}${ext}`
    wx.cloud.uploadFile({
      cloudPath,
      filePath: filePath,
      config: {
        env: 'cloud1-0gpl3oof20ee43c4'
      },
      success: res => {
        console.log('[上传文件] 成功：', res)

        app.globalData.fileID = res.fileID
        app.globalData.cloudPath = cloudPath
        app.globalData.fileUrl = filePath;

        console.log('具体图片大小请去云开发控制台，云存储一栏查看，当前文件为：' + cloudPath)
        
        that.setData({
          fileName: cloudPath,
          fileUrl: res.fileID
        },()=>{
          that.create();
          
        })


      },
      fail: e => {
        console.error('[上传文件] 失败：', e)
        wx.showToast({
          icon: 'none',
          title: '上传失败',
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    // this.onGetUUID();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    
  },
  onGetUUID: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'getUUID',
      data: {

      }
    })
    .then(res=>{
      console.log('[云函数] [getUUID]: ', res)
      that.setData({
        uuid: res.result.uuid
      })
    })
    .catch(err=>{
      console.error('[云函数] [getUUID] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  notify: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'notify',
      data: {
        action: '学习强国'
      }
    })
    .then(res=>{
      console.log('[云函数] [notify]: ', res)
      
    })
    .catch(err=>{
      console.error('[云函数] [notify] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})