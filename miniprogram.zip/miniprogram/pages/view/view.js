// miniprogram/pages/exam/exam.js
var app = getApp();
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentIndex: 0,
    showModal: false,
    score: 0,
    maxScore: 0,
    total: 0,
    btnText: '下一题'
  },
  questions: [],

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(util.getTime(new Date()))
    console.log(app.globalData);
    let that = this;
    this.setData({
      id: options.id
    },()=>{
      this.onQuery();
    })

    this.onGetTime();
    this.onGetOpenid();
    wx.getSystemInfo({
      success (res) {
        console.log(res.model)
        console.log(res.pixelRatio)
        console.log(res.windowWidth)
        console.log(res.windowHeight)
        console.log(res.language)
        console.log(res.version)
        console.log(res.platform)
        that.setData({
          windowWidth: res.windowWidth,
          windowHeight: res.windowHeight
        })

      }
    })

  },
  handleContact (e) {
    console.log(e.detail.path)
    console.log(e.detail.query)
  },
  onQuery: function(){
    const db = wx.cloud.database();

    db.collection('historys').doc(this.data.id)
    .get()
    .then(res => {
      console.log('[数据库] [查询记录] 成功: ', res)
      let history = res.data;
      let examid = history.examid;
      let exam = history.exam;
      let questions = history.questions;
      let state = history.state;

      

      this.questions = questions;

      
      this.setData({
        history,
        state,
        examid,
        exam,
        questions,
        question: questions[0],
        num: questions.length
      },()=>{
        console.log('已赋值完成')
        console.log('正确答案')
        console.log(this.data.question['answer']);
        wx.hideLoading()
      })
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // this.timeServal(9);
  },
  timeServal: function (t) {
    console.log(t)
    
    if (0 != t) {
      var e = t,
        a = 59,
        n = this;
        app.globalData.timeInterval = setInterval(function () {
        a < 10 ? n.setData({
          times: e + ":0" + a,
          ytimes: t - e + ":" + (59 - a)
        }) : n.setData({
          times: e + ":" + a,
          ytimes: t - e + ":" + (59 - a)
        }), --a < 0 && (e > 0 ? (a = 59, e--) : (a = 0, e = 0, n.setData({
          startTimeind: !0
        })));
      }, 1e3);

      
    } else this.setData({
      times: 0
    });
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    let unitMap = app.globalData.unitMap;
    this.setData({
      unitMap
    })

  },
  
  selectGo: function(e){
    console.log(e.currentTarget.dataset);
    let selectedCode = e.currentTarget.dataset.code;
    let questions = this.questions;
    let question = this.data.question;
    if(question.selected){
      return;
    }
    let index = question.index;
    let typecode = question.typecode;
    let options = question.options;
    let answer = question.answer;

    switch(typecode){
      case '01':
          options.map((option)=>{
            option.selected = false;
            if(option.code == selectedCode){
              option.selected = true;
            }
          });
          break;
      case '02':
          options.map((option)=>{
            if(option.code == selectedCode){
              option.selected = !option.selected;
            }
          });
          break;
      case '03':
          options.map((option)=>{
            option.selected = false;
            if(option.code == selectedCode){
              option.selected = true;
            }
          });
        break;  
      default: 
      console.log('其他未涉及题型')
    }

    question.options = options;
    questions[index] = question;

    this.questions = questions;
    this.setData({
      question
    })
  },
  nextGo: function(e){

    let mode = e.currentTarget.dataset.mode;

    let currentIndex = this.data.currentIndex;

    let questions = this.questions;
    let question = this.data.question;
    let index = question.index;
    let options = question.options;
    let answer = question.answer;


    let selected = false;
    let selectedCodeArr = [];
    options.forEach(option => {
      if(option.selected){
        selectedCodeArr.push(option.code)
        selected = true;
      }
    })

    if(!selected){
      wx.showModal({
        title: '提示',
        showCancel: false,
        content: '请先选择您的答案',
        confirmText: '我知道了',
        success (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      return;
    }

    console.log(answer);
    console.log(selectedCodeArr.sort().join(''));
    if(answer == selectedCodeArr.sort().join('')){
      question.status = true;
    }

    question.selected = true;
    question.mode = mode;

    console.log(question)

    questions[index] = question;

    this.questions = questions;
    this.setData({
      question
    },()=>{

        if(this.data.currentIndex == this.data.num-1){

          wx.showToast({
            title: '返回中',
            mask: true,
            icon: 'success',
            duration: 2000
          })
          
          // clearInterval(app.globalData.timeInterval)
          this.homeGo();
          // this.addHistory()
        }else{
          setTimeout(()=>{
            this.doNext();
          },1000)
        }
      
    })


  },
  homeGo: function(){
    wx.navigateBack({
      delta: 1
    })
  },
  doNext: function(){

    let currentIndex = this.data.currentIndex;
    let questions = this.questions;
    currentIndex++;

    let btnText = this.data.btnText;
    if(currentIndex == this.data.num-1){
      btnText = '确定';
    }

    this.setData({
      currentIndex,
      btnText,
      question: questions[currentIndex]
    },()=>{
      console.log('正确答案')
      console.log(this.data.question['answer']);
      console.log(this.data.currentIndex);
      console.log(this.data.question);
    })
  },
  addHistory: function(){
    let that = this;
    let questions = this.questions;

    let unitMap = this.data.unitMap;

    let score = 0;
    let num1 = 0;
    let num2 = 0;
    questions.forEach(ques => {
      if(ques.status){
        score += unitMap[ques.typecode];
      }

      let mode = ques.mode;
      switch(mode){
        case '+1':
          num1++;
          break;
        case '-1':
          num2++;
          break;
        default:
          console.log('未匹配情况');
      }
    })

    let {name, stuId, tel, branch} = app.globalData.userInfo;

    let time = this.data.time;
    let time2 = util.getTime(new Date());

    let time1 = this.data.time;

    console.log(time1);
    console.log(time2);
    let difftime = (new Date(time2) - new Date(time1))/1000; //计算时间差,并把毫秒转换成秒
    difftime = Math.abs(difftime);
    
    let minutes = parseInt(difftime%3600/60); // 分钟 -(day*24) 以60秒为一整份 取余 剩下秒数 秒数/60 就是分钟数
   	let seconds = parseInt(difftime%60);  // 以60秒为一整份 取余 剩下秒数
     
    let ytimes = minutes+':'+seconds;

    const db = wx.cloud.database()
    db.collection('historys').doc(this.data.id).update({
      data: {
        items: this.questions,
        state: 1
      }
    })
    .then(res=>{
      console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
      // let pNum1 = 5;
      // if(isNaN(minutes)){
      //   minutes = 0;
      // }
      // let pNum2 = 10 - parseInt(minutes);
      // let pNum3 = parseInt((score/this.data.num)*10);
      // let pNum = pNum1 + pNum2 + pNum3;
      // this.addPoints(pNum,pNum1,pNum2,pNum3);
      // if(this.data.total > 0 && this.data.maxScore < score){
      //   this.updateDaily(time1, time2, score);
      // }
      // if(this.data.total == 0){
      //   this.addDaily(time1,time2,score);
      // }
      this.setData({
        score
      },()=>{
        wx.hideToast();
        wx.redirectTo({
          url: "../examresult/examresult?score="+score+"&num=" + this.data.num + "&num1=" + num1 + "&num2=" + num2
        });
      })
    })
    .catch(err=>{
      console.error('[数据库] [新增记录] 失败：', err)
      wx.showToast({
        icon: 'none',
        title: '新增记录失败'
      })
    })

  },
  addPoints: function(pNum,pNum1,pNum2,pNum3){
    const db = wx.cloud.database();
    db.collection('points').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        action: '课堂测评',
        num: pNum,
        pNum1,
        pNum2,
        pNum3,
        time: this.data.time
      }
    })
    .then(res => {
      console.log(res)
      console.log('[数据库] [查询记录] 成功: ', res);
    })
    .catch((err)=>{
      console.log(err)

    })

  },
  addDaily: function(time1,time2,score){
    let that = this;

    let {name, grade, tel, branch} = app.globalData.userInfo;

    console.log(time1);
    console.log(time2);
    let date1 = new Date(time1.replace(/-/g, '/'));
    let date2 = new Date(time2.replace(/-/g, '/'));

    let difftime = ( Date.parse(date2)- Date.parse(date1) )/1000; //计算时间差,并把毫秒转换成秒
    difftime = Math.abs(difftime);

	  let minutes = parseInt(difftime%3600/60); // 分钟 -(day*24) 以60秒为一整份 取余 剩下秒数 秒数/60 就是分钟数
   	let seconds = parseInt(difftime%60);  // 以60秒为一整份 取余 剩下秒数
     
    let ytimes = minutes+':'+seconds;

    const db = wx.cloud.database()
    db.collection('daily').add({
      data: {
        examid: this.data.id,
        exam: this.data.exam,
        questions: this.questions,
        score,
        name,
        grade,
        tel,
        branch,
        today: this.data.today,
        time1,
        time2,
        ytimes: ytimes
      }
    })
    .then(res=>{
      console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
 
    })
    .catch(err=>{
      console.error('[数据库] [新增记录] 失败：', err)
      wx.showToast({
        icon: 'none',
        title: '新增记录失败'
      })
    })

  },

  rankGo: function(){
    console.log('003');
    let url = '../rank/rank';
    wx.redirectTo({
      url: url
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    clearInterval(app.globalData.timeInterval)
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  onGetTime: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'getTime',
      data: {}
    })
    .then(res=>{
      console.log('[云函数] [getTime]: ', res)
      that.setData({
        time: res.result.time,
        today: res.result.today
      })
    })
    .catch(err=>{
      console.error('[云函数] [getTime] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  onGetOpenid: function() {
    // 调用云函数
    let that = this;
    wx.cloud.callFunction({
      name: 'login',
      data: {

      }
    })
    .then(res => {
      console.log('[云函数] [login]: ', res)
      let openid = res.result.openid;
      that.setData({
        openid:openid
      },async ()=>{
        const db = wx.cloud.database();
        const res = await db.collection('daily').where({
          _openid: openid,
          today: app.globalData.today
        }).count();
        that.setData({
          total: res.total
        })
        console.log(res);
        if(res.total > 0){
          that.queryDaily(openid);
        }
      });
      
    }).catch(err => {
      console.error('[云函数] [login] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  queryDaily: function(openid){
    let that = this;
    const db = wx.cloud.database()
    db.collection('daily')
    .where({
      _openid: openid,
      today: app.globalData.today
    })
    .get()
    .then((res)=>{
      console.log('[数据库] [查询记录] 成功: ', res);

      let items = res.data;
      let maxScore = -1;
      let _id = '';
      items.forEach(item=>{
        if(item.score > maxScore){
          maxScore = item.score;
          _id = item._id;
        }
      })
      
      this.setData({
        _id,
        maxScore
      })
    })
    .catch((err)=>{
      console.log(err)
      console.error('[数据库] [查询记录] 失败：', err)
      wx.showToast({
        icon: 'none',
        title: '查询记录失败'
      })
    })
  },
  updateDaily: function(time1, time2, score){
    console.log(time1);
    console.log(time2);
    let date1 = new Date(time1.replace(/-/g, '/'));
    let date2 = new Date(time2.replace(/-/g, '/'));

    let difftime = ( Date.parse(date2)- Date.parse(date1) )/1000; //计算时间差,并把毫秒转换成秒
    difftime = Math.abs(difftime);
    
	  let minutes = parseInt(difftime%3600/60); // 分钟 -(day*24) 以60秒为一整份 取余 剩下秒数 秒数/60 就是分钟数
   	let seconds = parseInt(difftime%60);  // 以60秒为一整份 取余 剩下秒数
     
    let ytimes = minutes+':'+seconds;
    const db = wx.cloud.database();
    db.collection('daily').doc(this.data._id).update({
      // data 传入需要局部更新的数据
      data: {
        time1,
        time2,
        score,
        ytimes: ytimes
      }
    })
    .then(res=>{
      console.log('[数据库] [更新记录] 成功: ', res);
    })
    .catch(err=>{
      console.log(err);
      wx.showToast({
        title: '更新异常',
        icon: 'success',
        duration: 2000
      })
    })

  },
})