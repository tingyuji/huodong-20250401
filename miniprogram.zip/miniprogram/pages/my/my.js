// pages/my/my.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '微信用户',
    userInfo: {
      nickName: '微信用户',
      avatarUrl: 'https://picx.zhimg.com/v2-6fa81c23e6156f2152fa425a0c3d0994.jpeg'
    }, 
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.onGetOpenid();
  },
  onGetOpenid: function() {
    let that = this;
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        let openid = res.result.openid;
        app.globalData.openid = openid;
        this.setData({
          openid
        },()=>{
      
        })
       
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
       
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  toInfo(){
    wx.navigateTo({
      url: '../info/info',
    })
  },
  toAlbum(){
    wx.navigateTo({
      url: '../album/album',
    })
  },
  toPhoto: function(){
    console.log('003');
   
    
    let url = '../photo/photo';
    wx.navigateTo({
      url: url
    })
  },
  toKefu(){
    wx.navigateTo({
      url: '../kefu/kefu',
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.onQuery();
  },
  onQuery: function(){
    const db = wx.cloud.database()
    db.collection('profiles').doc(app.globalData.openid)
    .get()
    .then(res=>{
      console.log('[数据库] [查询记录] 成功: ', res);
      let {name, tel, userInfo} = res.data;
      this.setData({
        userInfo,
        name,
        tel
      })
    })
    .catch(err=>{
      console.error('[数据库] [查询记录] 失败：', err)
      wx.showToast({
        icon: 'none',
        title: '查询记录失败'
      })
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})