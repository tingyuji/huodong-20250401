// miniprogram/pages/welcome/welcome.js
var app = getApp();
const log = require('../../utils/log.js');
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num: 5,
    image: 'https://picx.zhimg.com/v2-d3a9d3e46aa49d36e1cf3c1b9531d8af.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    console.log(JSON.stringify(options));

    let mode = options.mode || '001';
    let id = options.id;
    console.log('id===',id);
    if(false && typeof id === 'undefined'){
      clearInterval(app.globalData.timeer)
      wx.redirectTo({
        url: '../activity/activity',
      })
      return
    }
    
    app.globalData.mode = mode;
    app.globalData.id = id;

    
    let random = new Date().getTime().toString(16);
    console.log(random);
    app.globalData.random = random;
    

    this.add(options);
    // log.info(JSON.stringify({
    //   path:"pages/welcome/welcome",
    //   ...options,
    //   time: +new Date()
    // }));
    let that = this;
    
    wx.getSystemInfo({
      success (res) {
        console.log(res.model)
        console.log(res.pixelRatio)
        console.log(res.windowWidth)
        console.log(res.windowHeight)
        console.log(res.language)
        console.log(res.version)
        console.log(res.platform)
        that.setData({
          windowWidth: res.windowWidth,
          windowHeight: res.windowHeight
        })

      }
    })

    if(!options.scene){
      console.log('非扫码进来');
      return;
    }

    this.setData({
      fromOpenid: options.scene
    },()=>{
      // this.lottery();
    })
  },
  addinfo: function(mode){
    // 在小程序代码中：
    wx.cloud.callFunction({
      name: 'addinfo',
      data: {
        mode
      }
    })
    .then(res=>{
      console.log('callFunction addinfo result: ', res);

    })
    .catch(err=>{
      console.error('[云函数] [addinfo] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  onQueryMode: function(){
    // 在小程序代码中：
    wx.cloud.callFunction({
      name: 'fetchMode',
      data: {

      }
    })
    .then(res=>{
      console.log('callFunction fetchMode result: ', res);
      if(res.result.total > 0){
        app.globalData.mode = '002';
      }
      console.log('app.globalData.mode',app.globalData.mode);
      


    })
    .catch(err=>{
      console.error('[云函数] [fetchMode] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  add: function(options){

    return;
    
    let time = util.getTime(new Date());

    const db = wx.cloud.database();
    db.collection('logs').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        path:"pages/welcome/welcome",
        ...options,
        time,
        updateTime: Date.now()
      }
    })
    .then(res => {
      console.log(res)
    })
    .catch((err)=>{
      console.log(err)
    })
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    app.globalData.prizeTime = Date.now();
    
    this.onGetOpenid();
    this.addinfo();

  },
  
  onGetOpenid: function() {
    // 调用云函数
    wx.showLoading({
      title: '加载中',
    })
    let that = this;
    wx.cloud.callFunction({
      name: 'login',
      data: {

      }
    })
    .then(res => {
      console.log('[云函数] [login]: ', res)
      app.globalData.openid = res.result.openid;
      let openid = res.result.openid;
      console.log('openid');
      console.log(openid);
      this.timeDown();
      that.setData({
        openid:openid,
      });
      wx.hideLoading();
    }).catch(err => {
      console.error('[云函数] [login] 调用失败', err)
      wx.navigateTo({
        url: '../deployFunctions/deployFunctions',
      })
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      num: 5
    })

  
  },
  
  toIndex: async function(){
    console.log('点击');
    return;

    clearInterval(app.globalData.timeer);
    let url = '/hc_answer/pages/index/index';
    wx.reLaunch({
      url: url
    })

  },
  toHome: async function(){
    clearInterval(app.globalData.timeer);
        wx.reLaunch({
          url: '/pages/home/home'
        })
        return;

    let that = this;
    const db = wx.cloud.database()
    const _ = db.command
    const res = await db.collection('profiles').where({
      _openid: this.data.openid
    }).count();
    console.log(res);
    let total = res.total;
    let url = '';
    switch(total){
      case 0:
        url = '/pages/login/login';
        wx.reLaunch({
          url: url
        })
        break;
      case 1: 
        url = '/pages/home/home';
        wx.reLaunch({
          url: url
        })
        break;
    }

  },
  timeDown: function(){
    let num = 5;
    app.globalData.timeer = setInterval(() => {
      num--;
      this.setData({
        num
      },()=>{
        if(num <= 0 ){
          clearInterval(app.globalData.timeer);
          this.toHome();
        }
      })
    }, 1000);
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    if(app.globalData.timeer){
      clearInterval(app.globalData.timeer)
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: app.globalData.sharetitle,
      path: "pages/welcome/welcome",
      imageUrl: app.globalData.shareImage
    };
  },
  onShareTimeline: function(res){
    if(res.from === 'menu'){
      console.log(res.target);
    }
    return {
      title: app.globalData.sharetitle,
      path: 'pages/welcome/welcome',
      imageUrl: app.globalData.shareImage
    }
  }
})