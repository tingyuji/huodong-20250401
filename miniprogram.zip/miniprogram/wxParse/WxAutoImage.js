module.exports = {
    wxAutoImageCal: function(o, e) {
        var i = 0, t = 0, g = 0, n = {};
        return wx.getSystemInfo({
            success: function(h) {
                console.dir(h), i = h.windowWidth, h.windowHeight, console.log("windowWidth" + i), 
                i < o ? (t = i, console.log("autoWidth" + t), g = t * e / o, console.log("autoHeight" + g), 
                n.imageWidth = t, n.imageheight = g) : (n.imageWidth = o, n.imageheight = e);
            }
        }), n;
    }
};