function e(e) {
    for (var t = {}, r = e.split(","), s = 0; s < r.length; s++) t[r[s]] = !0;
    return t;
}

function t(e) {
    return e.replace(/<\?xml.*\?>\n/, "").replace(/<.*!doctype.*\>\n/, "").replace(/<.*!DOCTYPE.*\>\n/, "");
}

function r(e) {
    var t = [];
    if (0 == o.length || !n) return (d = {
        node: "text"
    }).text = e, s = [ d ];
    e = e.replace(/\[([^\[\]]+)\]/g, ":$1:");
    for (var r = new RegExp("[:]"), s = e.split(r), i = 0; i < s.length; i++) {
        var l = s[i], d = {};
        n[l] ? (d.node = "element", d.tag = "emoji", d.text = n[l], d.baseSrc = a) : (d.node = "text", 
        d.text = l), t.push(d);
    }
    return t;
}

var s = "https", o = "", a = "", n = {}, i = require("./wxDiscode.js"), l = require("./htmlparser.js"), d = (e("area,base,basefont,br,col,frame,hr,img,input,link,meta,param,embed,command,keygen,source,track,wbr"), 
e("br,a,code,address,article,applet,aside,audio,blockquote,button,canvas,center,dd,del,dir,div,dl,dt,fieldset,figcaption,figure,footer,form,frameset,h1,h2,h3,h4,h5,h6,header,hgroup,hr,iframe,ins,isindex,li,map,menu,noframes,noscript,object,ol,output,p,pre,section,script,table,tbody,td,tfoot,th,thead,tr,ul,video")), c = e("abbr,acronym,applet,b,basefont,bdo,big,button,cite,del,dfn,em,font,i,iframe,img,input,ins,kbd,label,map,object,q,s,samp,script,select,small,span,strike,strong,sub,sup,textarea,tt,u,var"), u = e("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr");

e("checked,compact,declare,defer,disabled,ismap,multiple,nohref,noresize,noshade,nowrap,readonly,selected"), 
e("wxxxcode-style,script,style,view,scroll-view,block");

module.exports = {
    html2json: function(e, o) {
        e = t(e), e = i.strDiscode(e);
        var a = [], n = {
            node: o,
            nodes: [],
            images: [],
            imageUrls: []
        }, p = 0;
        return l(e, {
            start: function(e, t, r) {
                var l, m = {
                    node: "element",
                    tag: e
                };
                if (0 === a.length ? (m.index = p.toString(), p += 1) : (void 0 === (l = a[0]).nodes && (l.nodes = []), 
                m.index = l.index + "." + l.nodes.length), d[e] ? m.tagType = "block" : c[e] ? m.tagType = "inline" : u[e] && (m.tagType = "closeSelf"), 
                0 !== t.length && (m.attr = t.reduce(function(e, t) {
                    var r = t.name, s = t.value;
                    return "class" == r && (console.dir(s), m.classStr = s), "style" == r && (console.dir(s), 
                    m.styleStr = s), s.match(/ /) && (s = s.split(" ")), e[r] ? Array.isArray(e[r]) ? e[r].push(s) : e[r] = [ e[r], s ] : e[r] = s, 
                    e;
                }, {})), "img" === m.tag) {
                    m.imgIndex = n.images.length;
                    var h = m.attr.src;
                    "" == h[0] && h.splice(0, 1), h = i.urlToHttpUrl(h, s), m.attr.src = h, m.from = o, 
                    n.images.push(m), n.imageUrls.push(h);
                }
                if ("font" === m.tag) {
                    var f = [ "x-small", "small", "medium", "large", "x-large", "xx-large", "-webkit-xxx-large" ], g = {
                        color: "color",
                        face: "font-family",
                        size: "font-size"
                    };
                    for (var v in m.attr.style || (m.attr.style = []), m.styleStr || (m.styleStr = ""), 
                    g) if (m.attr[v]) {
                        var x = "size" === v ? f[m.attr[v] - 1] : m.attr[v];
                        m.attr.style.push(g[v]), m.attr.style.push(x), m.styleStr += g[v] + ": " + x + ";";
                    }
                }
                "source" === m.tag && (n.source = m.attr.src), r ? (void 0 === (l = a[0] || n).nodes && (l.nodes = []), 
                l.nodes.push(m)) : a.unshift(m);
            },
            end: function(e) {
                var t = a.shift();
                if (t.tag !== e && console.error("invalid state: mismatch end tag"), "video" === t.tag && n.source && (t.attr.src = n.source, 
                delete result.source), 0 === a.length) n.nodes.push(t); else {
                    var r = a[0];
                    void 0 === r.nodes && (r.nodes = []), r.nodes.push(t);
                }
            },
            chars: function(e) {
                var t = {
                    node: "text",
                    text: e,
                    textArray: r(e)
                };
                if (0 === a.length) n.nodes.push(t); else {
                    var s = a[0];
                    void 0 === s.nodes && (s.nodes = []), t.index = s.index + "." + s.nodes.length, 
                    s.nodes.push(t);
                }
            },
            comment: function(e) {}
        }), n;
    },
    emojisInit: function() {
        var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "", t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "/wxParse/emojis/", r = arguments[2];
        o = e, a = t, n = r;
    }
};