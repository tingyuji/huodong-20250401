/// <reference types="wechat-miniprogram" />
declare type CanvasContext = WechatMiniprogram.CanvasContext;
export declare function adaptor(ctx: CanvasRenderingContext2D): CanvasContext & CanvasRenderingContext2D;
export {};
